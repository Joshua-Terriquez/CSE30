#include <iostream>
#include <Array.h>
#include <LinkedList.h>
#include <RandomSupport.h>
#include <TimeSupport.h>

using namespace std;

int main(){
    // Your code here...
    
    randomizer Random = new_randomizer();
    ResizableArray TestArray;
    LinkedList TestList;
    //Data for 1
    uniform_distribution Distribution = new_distribution(0,99);
    timestamp start = current_time();
    for(long i=0; i < 100; i++){
        TestArray.append(i);
    }
    cout << TestArray.get(sample(Distribution, Random)) << endl;
    timestamp end = current_time();
    long duration = time_diff(start, end);
    
    cout << duration;
    
return 0;
}

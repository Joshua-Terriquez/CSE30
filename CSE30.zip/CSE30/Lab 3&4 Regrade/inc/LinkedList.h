#include <iostream>

struct LinkedList {
Node* head;
LinkedList(){
head = NULL;
}
void append(int value){
if (head == NULL){
head = new Node(value);
}
else{
// Allocate a new node with value
// Go to the last element of the list
// Make the next of the last element point to the new node
Node* newNode = new Node(value);
Node* temp = head;
while(temp->next != NULL){
temp = temp->next;
}
// At this point, temp is pointing to the last existing element of list
temp->next = newNode;
}
}
void insert(int index, int value) {
// Provide your code here
}
int get(int index){
// Provide your code here
}
void set(int index, int value){
// Provide your code here
}
void print (){
Node* temp = head;
while (temp != NULL) {
cout << temp->data << endl;
temp = temp->next;
}
}
˜LinkedList(){
Node* temp = head;
while(temp != NULL){
temp = temp->next;
delete head;
head = temp;
}
}
};
std::ostream& operator<< (std::ostream& os, const LinkedList& theList){
    Node* temp = theList.head;
    while (temp != NULL){
        os << temp->data << " ";
        temp = temp->next;
    }
    return os;
}
bool operator==(const LinkedList& other) const {
        Node* ours = head;
        Node* theirs = other.head;

        while (ours != NULL){
            if (theirs == NULL){
                return false;
            }
            if (ours->data != theirs->data){
                return false;
            }
            else{
                ours = ours->next;
                theirs = theirs->next;
            }
        }
        return theirs == NULL;
    }
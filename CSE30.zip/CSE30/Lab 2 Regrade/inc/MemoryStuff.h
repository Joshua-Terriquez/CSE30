#ifndef MemoryStuff_h
#define MemoryStuff_h

#include <string>
#include <sstream>

// A helper function to convert an integer (decimal value)
// to a hexadecimal representaion saved as a string
std::string decToHex(int x){
	std::stringstream ss;
	ss << std::hex << x;
	std::string res ( ss.str() );

	// Convert the result to upper case so hex values look better
	for (int i = 0; i< res.length(); ++i){
		res[i] = std::toupper(res[i]);
	}
    	
	// If the result is only one digit, add a zero to the front
	// Example: the number 10 in hexadecimal is A
	// so this function will return 0A, which is the same thing
    if (res.size() == 1){
        res = "0" + res;
    }

	return res;
}

std::string memoryContents(int x){
	int * p = &x;  // x occupies 4 boxes
	unsigned char* c = (unsigned char*)p;// cast int v values to char values.
	int i ;
	int arr[4];
	std::string line;
for(i=0; i < 4;i++){
	if (i ==0){
		arr[0]= (int)*(c+i);
	}else if (i==1){
		arr[1]=(int)*(c+i);
    }else if (i==2){
		arr[2]=(int)*(c+i);
    }else if (i==3){
		arr[3]=(int)*(c+i);
}
}
line = decToHex(arr[0])+ ":"+ decToHex(arr[1])+":"+decToHex(arr[2])+":"+decToHex(arr[3]);
	// Your code here

    return line; 
	// The return value above is just a placeholder.
	// Make the function return the appropriate string value.
}

#endif

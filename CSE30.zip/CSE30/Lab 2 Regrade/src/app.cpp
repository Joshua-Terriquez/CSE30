#include <iostream>
#include <MemoryStuff.h>

using namespace std;

int main(){
    // Your code here
    int response;
    cout << "Enter a integer: ";
    cin >> response;
    cout << memoryContents(response) << endl;
    
    return 0;
}

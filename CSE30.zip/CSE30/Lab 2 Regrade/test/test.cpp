#include <igloo/igloo.h>
#include <MemoryStuff.h>

using namespace igloo;

Context(DecimalToHexTest){
	Spec(Seven_07){
		// Check to see if we actually add a 0 in front of a single digit result
		Assert::That(decToHex(7), Equals("07"));
		//
	}
	Spec(Seven_08){
		// Check to see if we actually add a 0 in front of a single digit result
		Assert::That(decToHex(8), Equals("08"));
		//
	}
	Spec(Nine_09){
		// Check to see if we actually add a 0 in front of a single digit result
		Assert::That(decToHex(9), Equals("09"));
		//
	}

	Spec(Fifteen_0F){
		// Check to see if hex symbols A-F are in upper case
		Assert::That(decToHex(15), Equals("0F"));
	}
	Spec(Fourteen_0D){
		// Check to see if hex symbols A-F are in upper case
		Assert::That(decToHex(13), Equals("0D"));
	}
	Spec(Thirteen_0E){./bin/scratch d2h 13
		// Check to see if hex symbols A-F are in upper case
		Assert::That(decToHex(12), Equals("0C"));
	}
};

Context(MemoryContentFunctionTest){
	Spec(ThreeHundredFourteen_00_00_01_3A){
		Assert::That(memoryContents(314), Equals("3A:01:00:00")); 
	}
	Spec(sixthousandninehundredsixtynine_00_00_1B_39){
		Assert::That(memoryContents(6969), Equals("39:1B:00:00")); 
	}
	 Spec(FourHundredTwenty_00_00_01_A4){
		Assert::That(memoryContents(420), Equals("A4:01:00:00")); 
	}
	Spec(sixhundredsixtysix_00_00_02_9A){
		Assert::That(memoryContents(666), Equals("9A:02:00:00")); 
	}
	Spec(TwentyOne_00_00_00_15){
		Assert::That(memoryContents(21), Equals("15:00:00:00")); 
	}
	// Your code here
	Spec(TwoThousandTwenty_00_00_07_E4){
		Assert::That(memoryContents(2020), Equals("E4:07:00:00")); 
		// Put in the 4 correct values above in place of the xx
	}
};

int main() {
	// Run all the tests defined above
	return TestRunner::RunAllTests();
}

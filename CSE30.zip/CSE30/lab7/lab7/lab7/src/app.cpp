#include <iostream>
#include <fstream>
#include <algorithm>
#include <string>
#include <Array.h>
#include <LinkedList.h>
#include <TimeSupport.h>
#include <RandomSupport.h>
#include <BST.h>

using namespace std;

string reverse(string word){
    reverse(word.begin(), word.end());
    return word;
}

bool find(string word, ResizableArray& arr){
    for (long i = 0; i < arr.count; i++){
        if (word == arr[i]){
            return true;
        }
    }
    return false;
}

long f(string word){
	while (word.length()<4){
		word +=' ';
	}
    return word[0]*pow(128,3)+ word[1]*pow(128,2)+ word[2]*(128)+ word[3];

}
const long N = 268435455;
LinkedList* table =new LinkedList[N];

 void insert(string word){
     long index=f(word);
     table[index].append(word);
 }
 bool search(string revword){
     long index = f(revword);
     if(table[index].search(revword)){
         return true;
     }else{
         return false;
     }
 }

int main(int x){

    fstream file;

    ResizableArray words;
    
string fileName;// ( CHANGE FILE BY RUNNING CODE IN TERMINAL AND INPUTTING NAME......)
cout << "Enter file name: "<< fileName;
cin>> fileName;
    file.open(fileName,ios::in);
    if (file.is_open()){
        string tp;
        while(getline(file, tp)){
            words.append(tp);  
        }
        file.close(); 
    }
    else{
        cout << "Could not read file..." << endl;
    }
    timestamp start = current_time();
    long count= 0;
    for (long i = 0; i < words.count; i++){
        insert(words[i]); //goes through the list and organizes
    
    }
  
    for (long i = 0; i < words.count; i++){
       string rev = reverse(words[i]);
       if(search(rev)){
           count++;         // EASIER REVERSE FUNCTION.
       }
    }
    timestamp end= current_time();
            long duration = time_diff(start,end);

           
             cout << "Total time: "<<duration << " ms " <<endl;
   
    /*int count = 0;
    for (long i = 0; i < words.count; i++){
        // if (reverse(words[i]) ==  words[i]){
        string rev = reverse(words[i]);
        if (find(rev, words)){
       // cout << words[i] << endl;
            count++;
        }
       timestamp end= current_time();
            long duration = time_diff(start,end);
             cout<< duration<< endl;
    } */
   // LinkedList table[words.count];

    cout << "There were " << count << " words that match..." << endl;

    return x % words.count;
}
 























/*
using namespace std;

#ifndef HASH_H
#define HASH_H
 #include <iostream>
 #include<string>
 #include<cstdlib>
class hash{
    private:
        static const int tableSize=10;
    struct{
        string name;
        string drink;
        item* next;
    };
    item* HashTable[tableSize]; //hold item pointers
    public:
    hash();
    int Hash(string key);
    void AddItem(string name, string drink);
        /* hash::hash(){  initializes array...
  for (long i =0; i < tableSize; i++){
      HashTable[i]= new item;                   // constructor
       HashTable[i] -> name = NULL;
        HashTable[i]-> drink= NULL;
         HashTable[i]-> next= NULL;
  }
  void hash::AddItem(string name, string drink){
      int index= Hash(name);
  }
}
int hash::Hash(string key)
{
    int hash= 0;
    int index;
    // index = key.length();
 for(long i = 0; i < key.length();i++){
    hash= hash + (int)key[i];
 }
 index = hash % tableSize;  402 100 = 4 r 2 stores 2 into index
    return index;
    table size= 100;
     453/100= 4 r 53
}

};
#endif
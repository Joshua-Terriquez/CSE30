#include <iostream>
#include <cmath>

using namespace std;
long f (string s){
	while (s.length()<4){
		s +=' ';
	}
    return s[0]*pow(128,3)+s[1]*pow(128,2)+s[2]*pow(128,1)+s[3];

}
int main(int argc, char* argv[]){
cout<< f("DAD") << endl;
	return 0;
}
